/* esm.sh - d3-format@3.1.2/src/formatGroup */
function s(t,l){return function(a,n){for(var r=a.length,h=[],i=0,e=t[0],f=0;r>0&&e>0&&(f+e+1>n&&(e=Math.max(1,n-f)),h.push(a.substring(r-=e,r+e)),!((f+=e+1)>n));)e=t[i=(i+1)%t.length];return h.reverse().join(l)}}export{s as default};
//# sourceMappingURL=formatGroup.mjs.map