/* esm.sh - d3-format@3.1.2/src/precisionRound */
import n from"./exponent.mjs";function r(t,a){return t=Math.abs(t),a=Math.abs(a)-t,Math.max(0,n(a)-n(t))+1}export{r as default};
//# sourceMappingURL=precisionRound.mjs.map