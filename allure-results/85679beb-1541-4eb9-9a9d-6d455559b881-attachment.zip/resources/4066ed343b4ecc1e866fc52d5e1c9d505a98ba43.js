/* esm.sh - d3-format@3.1.2/src/identity */
function e(t){return t}export{e as default};
//# sourceMappingURL=identity.mjs.map