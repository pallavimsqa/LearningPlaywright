/* esm.sh - use-sync-external-store@1.6.0/with-selector */
import*as __0$ from"/react@^19.2.0?target=es2022";var require=n=>{const e=m=>typeof m.default<"u"?m.default:m,c=m=>Object.assign({__esModule:true},m);switch(n){case"react":return e(__0$);default:console.error('module "'+n+'" not found');return null;}};
var O=Object.create;var y=Object.defineProperty;var N=Object.getOwnPropertyDescriptor;var W=Object.getOwnPropertyNames;var w=Object.getPrototypeOf,G=Object.prototype.hasOwnProperty;var I=(e=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(e,{get:(r,u)=>(typeof require<"u"?require:r)[u]}):e)(function(e){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')});var E=(e,r)=>()=>(r||e((r={exports:{}}).exports,r),r.exports);var _=(e,r,u,f)=>{if(r&&typeof r=="object"||typeof r=="function")for(let o of W(r))!G.call(e,o)&&o!==u&&y(e,o,{get:()=>r[o],enumerable:!(f=N(r,o))||f.enumerable});return e};var k=(e,r,u)=>(u=e!=null?O(w(e)):{},_(r||!e||!e.__esModule?y(u,"default",{value:e,enumerable:!0}):u,e));var z=E(R=>{"use strict";var s=I("react");function p(e,r){return e===r&&(e!==0||1/e===1/r)||e!==e&&r!==r}var A=typeof Object.is=="function"?Object.is:p,B=s.useSyncExternalStore,C=s.useRef,F=s.useEffect,H=s.useMemo,J=s.useDebugValue;R.useSyncExternalStoreWithSelector=function(e,r,u,f,o){var l=C(null);if(l.current===null){var c={hasValue:!1,value:null};l.current=c}else c=l.current;l=H(function(){function d(t){if(!j){if(j=!0,a=t,t=f(t),o!==void 0&&c.hasValue){var i=c.value;if(o(i,t))return v=i}return v=t}if(i=v,A(a,t))return i;var V=f(t);return o!==void 0&&o(i,V)?(a=t,i):(a=t,v=V)}var j=!1,a,v,b=u===void 0?null:u;return[function(){return d(r())},b===null?void 0:function(){return d(b())}]},[r,u,f,o]);var n=B(e,l[0],l[1]);return F(function(){c.hasValue=!0,c.value=n},[n]),J(n),n}});var M=E((P,D)=>{"use strict";D.exports=z()});var m=k(M()),{useSyncExternalStoreWithSelector:Q}=m,T=m.default??m;export{T as default,Q as useSyncExternalStoreWithSelector};
/*! Bundled license information:

use-sync-external-store/cjs/use-sync-external-store-with-selector.production.js:
  (**
   * @license React
   * use-sync-external-store-with-selector.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
//# sourceMappingURL=with-selector.mjs.map