/* esm.sh - d3-format@3.1.2/src/precisionFixed */
import a from"./exponent.mjs";function n(t){return Math.max(0,-a(Math.abs(t)))}export{n as default};
//# sourceMappingURL=precisionFixed.mjs.map