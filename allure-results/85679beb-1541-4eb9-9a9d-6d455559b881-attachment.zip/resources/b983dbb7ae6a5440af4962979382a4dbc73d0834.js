/* esm.sh - d3-format@3.1.2/src/precisionPrefix */
import t from"./exponent.mjs";function r(a,o){return Math.max(0,Math.max(-8,Math.min(8,Math.floor(t(o)/3)))*3-t(Math.abs(a)))}export{r as default};
//# sourceMappingURL=precisionPrefix.mjs.map