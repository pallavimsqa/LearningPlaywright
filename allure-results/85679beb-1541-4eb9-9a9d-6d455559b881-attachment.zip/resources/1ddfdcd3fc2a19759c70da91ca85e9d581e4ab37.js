/* esm.sh - d3-format@3.1.2/src/exponent */
import{formatDecimalParts as a}from"./formatDecimal.mjs";function o(t){return t=a(Math.abs(t)),t?t[1]:NaN}export{o as default};
//# sourceMappingURL=exponent.mjs.map